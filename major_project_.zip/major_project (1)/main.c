#include <lpc214x.h>    /* Include specific LPC2148 hardware register definitions */

//#include "esp01.h"     // (Commented out header include for ESP01 module)
#include "delay.h"      /* Include custom millisecond delay functions */

#include "defines.h"    /* Include general macro configurations */
//#include "esp01.h"     // (Secondary duplicate commented out header include)
#include "lcd.h"        /* Include standard LCD interface tracking drivers */

#include "dht11.h"      /* Include DHT11 humidity/temperature sensor routines */
#include "uart0.h"      /* Include Serial interface initialization and transmission routines */
#include "interrupt.h"  /* Include EINT1 vector assignment configurations */
#include"kpm.h"         /* Include 4x4 matrix keypad scanning function drivers */

#define USER 2          // Interval macro matching minutes (every 2 mins) for tracking ThingSpeak data updates

// Function Prototypes for dependencies defined across secondary modular files
void RTC_Init(void);
void GetRTCTimeInfo(int *,int *,int *);
void esp01_connectAP(void);
void esp01_sendToThingspeak(int);
void esp01_sendToThingspeak2(int);
void esp01_sendToThingspeak3(int,int);


unsigned char condition; // General configuration check state tracking flag variable

// Default fallback environmental threshold limits assigned for system execution setup
unsigned char temp_high=35;        // Maximum safety boundary for critical heat alert limits
unsigned char temp_medium_low=25;  // Low-end boundary configuration matching standard warmth range
unsigned char temp_medium_high=34; // Upper-end configuration tracking comfortable warmth threshold
unsigned char hum_high=70;         // Maximum baseline cutoff parameter for standard soil saturation
unsigned char hum_low=50;          // Minimum trigger cutoff boundary for standard humidity tracking

// Automated timer duration parameters representing localized run profiles in milliseconds
unsigned int time1=60000;          // Run Profile Level 1 setup timing (1 Minute duration block)
unsigned int time2=120000;         // Run Profile Level 2 setup timing (2 Minutes duration block)
unsigned int time3=180000;         // Run Profile Level 3 setup timing (3 Minutes duration block)

int hour,min,sec;                 // Real-Time Clock current frame context collection trackers
int temp,hum,motor,flag;           // Tracking status values for previous runtime minutes, motor status, and menu event flags
unsigned char humidity_integer, humidity_decimal, temp_integer, temp_decimal, checksum; // Extraction segments for DHT11 data payload  

/* 
 * Function: main
 * Description: Master application control pipeline initializing components, handling real-time loops,
 *              parsing data updates, and checking state triggers to alter physical output relays.
 */
int main (void)

{
// char key; // (Commented out variable for local keypad tracking storage)
IO0DIR &= ~(1<<5);      // Configure P0.5 pin position explicitly clear to 0 for tracking Digital input from Soil Moisture sensor
IO0DIR |=  (1<<20);     // Configure P0.20 pin position explicitly active to 1 to work as Output routing for Driving the Relay/Bulb  
	RTC_Init();         // Initialize the internal Real-Time Clock module parameters
	LCD_Init();         // Initialize the liquid crystal display pins and clean tracking memory registers
	initkpm();          // Configure and lock matrix keypad port line connection arrays
  InitUART0();        // Configure serial communications baud levels and flag registrations
 	init_intr();        // Setup configuration pathways for external edge trigger EINT1 (User Input Interrupt)
  	Write_CMD_LCD(0x80);// Drive display pointer cursor positioning alignment baseline to start location Line 1 Column 1
	Write_str_LCD("ESP01 Interface"); // Flash setup validation sequence greeting message string text 
  delay_ms(1000);     // Pause state block to verify interface notification rendering text clearly
  esp01_connectAP();   // Initiate standard handshake setup connecting network tracking configurations over Wi-Fi
		   if(flag==1)     // Test check if user input interrupt triggered execution flags during the initial startup process
	{
		menu();	        // Open crop profiles update configuration selection screens
		flag=0;         // Wipe and reset tracking state flag marker to standard processing mode baseline
	}
	while(1)            // Begin infinite hardware background monitoring and automated management loop

	{		  	Write_CMD_LCD(0x01); // Wipe all remaining visual elements off screen tracking planes
     	GetRTCTimeInfo(&hour,&min,&sec); // Extract recent time configurations updates directly from internal hardware registers
		dht11_request();    // Send start pulse sequence to wake up and sync communication lines with DHT11 sensor

		dht11_response();   // Wait for data parsing acknowledge sequence from localized physical climate sensor

		humidity_integer = dht11_data(); // Fetch raw complete integer segment tracking Relative Humidity values

		humidity_decimal = dht11_data(); // Fetch raw fractional tracking segment for climate moisture levels

		temp_integer = dht11_data();     // Fetch raw complete integer segment mapping Temperature readings

		temp_decimal = dht11_data();     // Fetch raw fractional tracking segment for ambient thermal readings

		checksum = dht11_data();         // Fetch the calculated checksum validation byte sent by the sensor

		if( (humidity_integer + humidity_decimal + temp_integer + temp_decimal) != checksum ) // Verify data validity using math checksum test

			Write_str_LCD("Checksum Error\r\n"); // Print system notification error tracking transmission corruption problems

		else

		{
													    
			Write_CMD_LCD(0x80); // Adjust current visualization grid back onto home tracking alignment (Line 1, Column 1)

			Write_str_LCD("H : "); // Write tracking text tag identifying Humidity data readout

			Write_int_LCD(humidity_integer); // Output standard integer tracking value for relative humidity on display screen

			Write_DAT_LCD('.');  // Render separated fractional tracking component alignment dot

			Write_int_LCD(humidity_decimal); // Output residual tracking values mapped for minor humidity increments

			Write_str_LCD(" % RH "); // Write complete units format tracking text suffix for relative humidity

			Write_CMD_LCD(0xC0); // Move cursor tracking line positioning directly to top location of Line 2

			Write_str_LCD("T : "); // Write tracking text tag identifying Temperature data readout

			Write_int_LCD(temp_integer); // Output standard captured temperature value on screen face

			Write_DAT_LCD('.');  // Render separated fractional tracking component alignment dot

			Write_int_LCD(temp_decimal); // Output remaining minor fractional temperature tracking values

			Write_DAT_LCD(223);  // Render custom generation ASCII special character code representing degree symbol (�)

			Write_str_LCD("C");  // Finalize printing out structural temperature reference text label matching Celsius tracking scale

			Write_CMD_LCD(0xD4); // Shift visualization cursor tracking down line grid to first position on Line 3

			Write_str_LCD("Checksum : "); // Render confirmation code title text indicator across display line

			Write_int_LCD(checksum); // Output total confirmation variable data across active output row

			delay_ms(3000);      // Stability delay block allowing users to observe current climate updates clearly

			Write_CMD_LCD(0x01); // Clear current contents away to prepare clean area for timing variables tracking data
			Write_int_LCD(min);  // Diagnostic trace print showing active current clock runtime minutes on LCD panel
			delay_ms(300);       // Brief pause before refreshing primary operations layout
			 Write_CMD_LCD(0x01);// Wipe tracking visual fields again to restore system operational alignment
			if(min%USER==0 && temp!=min){ // Conditional validation filter tracking if current minute matches data update period interval limit
								  temp=min; // Update tracking tracking flag register parameter to match active clock frame state
			esp01_sendToThingspeak3(temp_integer,humidity_integer); // Transmit combined climate data arrays up to Cloud IoT servers
			}
			if(flag==1)          // Secondary user execution poll check parsing state changes happening during display processing
	{
		menu();	                 // Redirect runtime track to process profile tracking configuration modifications
		flag=0;                  // Neutralize active signal status flag registers
	}
			// Check only when soil is dry
// Here: P0.5 = 1 means soil dry

// Check only when soil is dry
if((IO0PIN & (1<<5)) != 0)       // Bitwise check input pin state mapping: if bit 5 evaluates true (High), soil moisture sensor flags Dry earth
{
    if((temp_integer >= temp_high) && (humidity_integer >= hum_high)) // Condition 1 testing evaluation branch layout logic
    {
        // High temperature + High humidity + Soil dry
        IO0SET = (1<<20);        // Set P0.20 High to pull in real world drive relay contacts forcing primary irrigation motor active
		motor=1;                 // Record active driver status parameter state variable inside global tracker register
		esp01_sendToThingspeak(motor); // Log update tracking active state transformation record up onto web service dashboard
		
			Write_CMD_LCD(0x80); // Move print focus to Top row location line 1 position

			Write_str_LCD("motor on 1 min"); // State operational tracking notification text updates shown directly to user
        delay_ms(time1);         // Enforce blocking system wait delay mapping active irrigation runtime (1 minute standard)
        IO0CLR = (1<<20);        // Clear P0.20 Low to disconnect active output logic dropping motor back inactive
		motor=0;                 // Record tracking state variable changes locally within system memory registers
		esp01_sendToThingspeak(motor); // Sync active shutdown record updates over serial transmission channels up to cloud dashboard
    }
    else if((temp_integer >= temp_medium_low && temp_integer <= temp_medium_high) && // Condition 2 testing evaluation branch layout logic
            (humidity_integer < hum_low))
    {
        // Medium temperature + Low humidity + Soil dry
        
        IO0SET = (1<<20);        // Pull driver relay output lines high to start active water distribution system tasks
	motor=1;                     // Record active tracking status variable updates
		esp01_sendToThingspeak(motor); // Broadcast operational profile adjustments out towards remote network servers
		
			Write_CMD_LCD(0x80); // Move layout track tracking directly back towards start tracking line

			Write_str_LCD("motor on 2 min"); // Display text stating current automation running sequence parameters
        delay_ms(time2);         // Keep irrigation line operational for full profile interval length (2 minutes standard)
        IO0CLR = (1<<20);        // Drive output state connection lines down to cut off control current parameters
	motor=0;                     // Log inactive machine state tracking changes inside storage parameters
		esp01_sendToThingspeak(motor); // Transmit update records confirming operations finished up to monitoring servers
    }
    else if((temp_integer >= temp_high) && (humidity_integer < hum_low)) // Condition 3 testing evaluation branch layout logic
    {
        // High temperature + Low humidity + Soil dry
           motor=1;              // Immediately note state variation happening within runtime variable registers
		esp01_sendToThingspeak(motor); // Push alert signal state updates forward over network hardware layers
        IO0SET = (1<<20);        // Turn on system output pin P0.20 to engage external distribution water pump structures
		
			Write_CMD_LCD(0x80); // Bring cursor alignment targets around back onto baseline tracking positions

			Write_str_LCD("motor on 3 min"); // Update character layout line confirming custom critical automation state parameters
        delay_ms(time3);         // Drive continuous operation running state tracking until limit timer drops out (3 minutes standard)
        IO0CLR = (1<<20);        // Reset terminal line configurations back down to standard open safe setup limits
		motor=0;                 // Record device operations closed status back inside storage variables
		esp01_sendToThingspeak(motor); // Send terminal message validation tracking parameters to server interfaces
    }
    else                         // Fallback protection layout path capturing unexpected dry situations missing explicit guidelines
    {
         IO0SET = (1<<20);       // Initialize basic system support configuration outputs by applying current to drive lines
		 motor=1;                // Flag driver tracking properties active
		esp01_sendToThingspeak(motor); // Transmit verification alerts out to remote system dashboards
			Write_CMD_LCD(0x80); // Lock view alignment configurations direct onto target display fields

			Write_str_LCD("motor on 1 min"); // Write status tracking metrics verifying basic fallback configuration active
        delay_ms(time1);         // Maintain operations layout path matching primary fallback time interval lengths
        IO0CLR = (1<<20);        // Clear tracking configuration outputs down back down to silent baseline conditions
		motor=0;                 // Save baseline operational states safely inside system storage memory tracking areas
		esp01_sendToThingspeak(motor); // Push closing sequence state updates out across monitoring frameworks
    }
}
// Soil sensor D0 connected to P0.5
// Bulb / Relay connected to P0.20
	 }
	if(flag==1)                  // Final recursive loop tracking check parsing configuration update requests from user interfaces
	{
		menu();	                 // Launch menu screen configuration parameters safely from main processing timeline paths
		flag=0;                  // Balance system data parameters back to clear normal status settings
	}
}
}
