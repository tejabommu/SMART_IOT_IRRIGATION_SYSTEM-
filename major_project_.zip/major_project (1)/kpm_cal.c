#include <lpc21xx.h>
#include "delay.h"
#include "lcd.h"

/* ===== KEYPAD ===== */
char keypad[4][4] =
{
    {'1','2','3','4'},
    {'5','6','7','8'},
    {'9','0','*','#'},
    {'A','B','C','D'}
};

void initkpm(void)
{
    IODIR1 |= (0xF<<16);
    IODIR1 &= ~(0xF<<20);
    IOSET1 = (0xF<<16);
}

char keyscan()
{
    unsigned int r,c;

    while(1)
    {
        for(r=0;r<4;r++)
        {
            IOSET1 = (0xF<<16);
            IOCLR1 = (1<<(16+r));
            delay_ms(10);

            if(!(IOPIN1&(1<<20))) c=0;
            else if(!(IOPIN1&(1<<21))) c=1;
            else if(!(IOPIN1&(1<<22))) c=2;
            else if(!(IOPIN1&(1<<23))) c=3;
            else continue;
	    delay_ms(20);
            while(!(IOPIN1&(1<<(20+c))));
            delay_ms(20);

            return keypad[r][c];
        }
    }
}


int readnum()
{
int num=-1,c=0;
char key;
while(1){
        key = keyscan();
        if(key>='0' && key<='9')
        {
		if(num==-1)	{
			num=0;
		}
            num = num*10 + (key-'0');
			c++;
            Write_DAT_LCD(key);
        }
			  else if(key == '*' && c)   // Backspace
        {
            num = num / 10;
			if(num==0){
			num=-1;
			}
			 c--;
            Write_CMD_LCD(0x10); // move cursor left
            Write_DAT_LCD(' ');     // erase
            Write_CMD_LCD(0x10); // move left again
        }
        else if(key=='C')
		 break;
        }
        return num;

}
