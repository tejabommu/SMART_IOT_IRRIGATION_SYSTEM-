#include <LPC214x.h>
#include "buzzer.h"

#define BUZZER (1<<21)

void buzzer_on()
{
    IOSET0 = BUZZER;
}

void buzzer_off()
{
    IOCLR0 = BUZZER;
}
