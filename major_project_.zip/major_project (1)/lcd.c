#include<LPC21xx.h> // Include standard LPC21xx microcontroller register definitions

#include "delay.h"  // Include user-defined delay function declarations
#include "lcd.h"    // Include LCD function prototypes
#include "defines.h"// Include custom macro definitions (like WRITEBYTE, WRITEBIT)

// Define pin positions on GPIO Port 0 for LCD interfacing
#define LCD_DAT 8   // Data pins starting bit position (typically D0-D7 mapped to P0.8-P0.15)
#define RS 16       // Register Select pin mapped to P0.16
#define RW 18       // Read/Write pin mapped to P0.18
#define EN 17       // Enable pin mapped to P0.17

/* 
 * Function: LCD_Init
 * Description: Configures GPIO pins as outputs and initializes the 16x2 LCD 
 *              controller into 8-bit mode using the standard initialization sequence.
 */
void LCD_Init(void)
{
		WRITEBYTE(IODIR0,LCD_DAT,0xFF); // Set 8 data lines as output pins in Port 0 Direction register
		WRITEBIT(IODIR0,RS,1);         // Set RS pin as output
		WRITEBIT(IODIR0,RW,1);         // Set RW pin as output
		WRITEBIT(IODIR0,EN,1);         // Set EN pin as output
		delay_ms(16);                  // Wait for more than 15ms after VCC rises to 4.5V
    
    // Hardware initialization reset sequence for HD44780 LCD compliance
    Write_CMD_LCD(0x30);           // First Special Function Set command
    delay_ms(6);                   // Wait for more than 4.1ms
		Write_CMD_LCD(0x30);           // Second Special Function Set command
    delay_ms(1);                   // Wait for more than 100us
    Write_CMD_LCD(0x30);           // Third Special Function Set command
    delay_ms(1);                   // Wait for execution time
    
    Write_CMD_LCD(0x38);           // Function Set: 8-bit mode, 2 lines, 5x7 dots font 
		Write_CMD_LCD(0x10);           // Display Control: Turn OFF the display
		Write_CMD_LCD(0x01);           // Clear Display: Clears display RAM and returns cursor home
    Write_CMD_LCD(0x06);           // Entry Mode Set: Increment cursor automatically (Shift right), no display shift
		Write_CMD_LCD(0x0f);           // Display Control: Turn ON display, Show cursor, Enable cursor blinking

}

/* 
 * Function: Write_CMD_LCD
 * Description: Sends an instruction/command byte to the LCD by pulling RS Low.
 */
void Write_CMD_LCD(char cmd)
{
  WRITEBIT(IOCLR0,RS,1);           // Clear RS pin (RS = 0) to select the Instruction Register
	Write_LCD(cmd);                  // Send the command byte to the data bus
}

/* 
 * Function: Write_DAT_LCD
 * Description: Sends a data byte (ASCII character) to the LCD by pulling RS High.
 */
void Write_DAT_LCD(char dat)
{
	WRITEBIT(IOSET0,RS,1);           // Set RS pin (RS = 1) to select the Data Register
	Write_LCD(dat);                  // Send the data byte to the data bus
}

/* 
 * Function: Write_LCD
 * Description: Low-level driver function that places data on the bus 
 *              and generates the high-to-low latching pulse on the Enable pin.
 */
void Write_LCD(char ch)
{
	WRITEBIT(IOCLR0,RW,1);           // Clear RW pin (RW = 0) to put LCD in Write mode
	WRITEBYTE(IOPIN0,LCD_DAT,ch);    // Write the 8-bit character/command onto the Port 0 data pins
	WRITEBIT(IOSET0,EN,1);           // Set Enable pin high (EN = 1) to start the pulse
	WRITEBIT(IOCLR0,EN,1);           // Clear Enable pin low (EN = 0) to latch data on falling edge
	delay_ms(2);                     // Execution delay for the LCD to process the written byte
}

/* 
 * Function: Write_str_LCD
 * Description: Accepts a pointer to a string and prints characters until the null terminator is hit.
 */
void Write_str_LCD(char *p)
{
	while(*p)                        // Loop through each character until the null terminator ('\0')
		Write_DAT_LCD(*p++);         // Print current character and advance pointer address	
}

/* 
 * Function: Write_int_LCD
 * Description: Converts a signed integer to its ASCII character components and prints them.
 */
void Write_int_LCD(signed int n)
{
	char a[10],i=0;                  // Temporary buffer array to hold digit characters, and an index tracker
    if(n<0)                          // Check if the integer value is negative
	{
		Write_DAT_LCD('-');          // Display the negative sign on screen
		n=-n;                        // Convert the number to its absolute positive equivalent
	}
	do                       
	{
		a[i++]=n%10+48;	             // Extract the last digit, convert to ASCII value (+48), store in array
		n=n/10;                      // Remove the last digit from the integer
	}while(n);                       // Repeat until the number becomes zero
  
  for(;i>0;i--)                      // Loop backwards through the buffer array because digits were extracted in reverse
		Write_DAT_LCD(a[i-1]);       // Output each character to the LCD screen
}
