buzzer.o: buzzer.c
buzzer.o: C:\KeilARM\ARM\INC\Philips\LPC214x.h
