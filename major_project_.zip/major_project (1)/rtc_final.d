rtc_final.o: rtc_final.c
rtc_final.o: C:\KeilARM\ARM\INC\Philips\lpc21xx.h
