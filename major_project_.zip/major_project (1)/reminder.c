#include <LPC214x.h>
#include "reminder.h"

MED_TIME med[MAX_MED];
unsigned char med_count = 0;

void add_medicine(unsigned char h, unsigned char m)
{
    if(med_count < MAX_MED)
    {
        med[med_count].hour = h;
        med[med_count].min = m;
        med_count++;
    }
}

unsigned char check_medicine(unsigned char h, unsigned char m)
{
    unsigned char i;

    for(i=0;i<med_count;i++)
    {
        if(med[i].hour == h && med[i].min == m)
        {
            return 1;
        }
    }

    return 0;
}
