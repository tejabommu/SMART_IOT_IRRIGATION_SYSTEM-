#include"types.h"
void initkpm(void);
u32 colscan(void);
u32 rowcheck(void);
u32 colcheck(void);
u32 keyscan(void);
int readnum(void);
