kpm_cal.o: kpm_cal.c
kpm_cal.o: C:\KeilARM\ARM\INC\Philips\lpc21xx.h
kpm_cal.o: delay.h
kpm_cal.o: lcd.h
