#include <LPC21xx.H>  /* LPC21xx microcontroller register definitions */

#include "uart0.h"

char buff[200]="hello",dummy; // Global receive buffer array, and a dummy read variable
unsigned char i=0,ch,r_flag;  // Buffer index tracker, character buffer, and general receive status flag

/* 
 * Function: UART0_isr
 * Description: Interrupt Service Routine for UART0. Automatically executes when a byte 
 *              is received or when the Transmit Holding Register becomes empty.
 */
void UART0_isr(void) __irq
{
  if((U0IIR & 0x04)) // Check the Interrupt Identification Register bits to see if a Receive Data Available (RDA) interrupt triggered
  {
		ch = U0RBR;	/* Read the Receiver Buffer Register to fetch the character and clear the interrupt */
		if(i<200)   // Boundary check to prevent a buffer overflow attack or memory corruption
			buff[i++] = ch; // Store the received character into the global buffer and increment the array pointer
  }
  else
  {
      dummy=U0IIR; // Read the Interrupt Identification Register to clear a Transmit Holding Register Empty (THRE) source interrupt
  
  }
   VICVectAddr = 0; /* Dummy write to the Vector Address register to signal the end of interrupt execution to the VIC hardware */
}

/* 
 * Function: InitUART0
 * Description: Configures the pin mapping, frame structure, baud rate settings, 
 *              and registers the Vectored Interrupt Controller settings for UART0.
 */
void InitUART0 (void) /* Initialize Serial Interface       */ 
{  
            		
  PINSEL0 = 0x00000005; /* PINSEL0 bits 0:3 configured to 0101 to map P0.0 as TxD0 and P0.1 as RxD0 pins */
  U0LCR = 0x83;         /* Line Control Reg: Set 8 bits, no Parity, 1 Stop bit. Set bit 7 (DLAB=1) to enable Baud Rate latch access */
  U0DLL = DIVISOR;      /* Load calculated Divisor Latch Least-Significant Byte for targeted Baud Rate based on Peripheral Clock */
	U0DLM = DIVISOR>>8;  /* Shift right by 8 to extract and load the Divisor Latch Most-Significant Byte */
  U0LCR = 0x03;         /* Clear bit 7 (DLAB = 0) to lock the baud rate configuration and unlock access to the data buffers */
  
  #if UART_INT_ENABLE > 0 // Conditional compilation block checking if global interrupt flag parameter is toggled active

  VICIntSelect = 0x00000000; // Map UART0 interrupt source as standard IRQ (0) instead of Fast Interrupt Request (FIQ)
  VICVectAddr0 = (unsigned)UART0_isr; // Assign the execution memory address of our ISR wrapper to Slot 0 vector location
  VICVectCntl0 = 0x20 | 6; /* Slot 0 enabled (bit 5 = 0x20) and combined with Channel 6 ID assigned specifically for UART0 peripheral */
  VICIntEnable = 1 << 6;   /* Enable global system-level routing matching Interrupt Channel 6 in the VIC mask register */
 
  U0IER = 0x03;       /* Peripheral level: Enable UART0 RX (bit 0) and THRE Transmit (bit 1) interrupt pipelines */   
             
  #endif
						
}

/* 
 * Function: UART0_Tx
 * Description: Transmits a single character blocking loop style over serial bus.
 */
void UART0_Tx(char ch)  /* Write character to Serial Port    */  
{ 
  while (!(U0LSR & 0x20)); // Polling wait until Line Status Register Bit 5 (THRE) turns to 1, indicating TX buffer is completely empty
  U0THR = ch;                // Load the byte variable payload into the Transmit Holding Register to start physical shift out
}

/* 
 * Function: UART0_Rx
 * Description: Reads a single received character using a basic polling architecture.
 */
char UART0_Rx(void)    /* Read character from Serial Port   */
{                     
  while (!(U0LSR & 0x01)); // Polling wait until Line Status Register Bit 0 (RDR) shifts to 1, signaling data arrived in hardware buffer
  return (U0RBR);          // Return the character read out directly from the hardware internal Receiver Buffer Register
}

/* 
 * Function: UART0_Str
 * Description: Takes an active address reference to a string array loop printing characters until hitting the terminator value.
 */
void UART0_Str(char *s)
{
   while(*s)               // Test string element loop index context until encountering terminal string character code zero ('\0')
       UART0_Tx(*s++);     // Submit indexed pointer element to physical data transmission and jump memory allocation address
}

/* 
 * Function: UART0_Int
 * Description: Disassembles an unsigned base integer value into distinct elements print printing them forward order.
 */
void UART0_Int(unsigned int n)
{
  unsigned char a[10]={0,0,0,0,0,0,0,0,0,0}; // Array tracking block storage buffer to safely hold maximum layout characters
  int i=0; // Internal array index tracker initialization
  if(n==0) // Edge scenario trap to immediately pass out static zero directly if string target parameters are raw empty
  {
    UART0_Tx('0'); // Submit single ASCII numeral zero character over the wire
		return;        // Terminate routine processing
  }
  else
  {
     while(n>0)    // Arithmetic extraction parsing loop
	 {
	   a[i++]=(n%10)+48; // Modulo extraction gets last isolated digit value, shifts it up to ASCII set (+48), saves to memory buffer
	   n=n/10;           // Divide data payload balance down base-10 to step forward onto subsequent numerical placement tracking
	 }
	 --i; // Step back memory address boundary index pointer array context by one step away from empty trailing array sector
	 for(;i>=0;i--) // Loop downwards sequence to invert backward string buffer to standard printing alignment
	 {
	   UART0_Tx(a[i]); // Output characters via individual serial packet pipeline
	 }
   }
}

/* 
 * Function: UART0_Float
 * Description: Isolates float values into split integer base and precise two-digit decimal string elements for rendering.
 */
void UART0_Float(float f)
{
  int x;          // Processing context container allocation 
  float temp;     // Mantissa tracking workspace allocation
  x=f;            // Direct implicit conversion assignment strips out float variables leaving only raw base integer segments
  UART0_Int(x);   // Transmit leading complete base numerical components
  UART0_Tx('.');  // Transmit standard isolated radical point indicator literal
  temp=(f-x)*100; // Subtract away whole value base context, shifting remaining balance up 2 fractional locations into integer frame
  x=temp;         // Implicit cast isolates resulting two floating character places safely into standard variable state
  UART0_Int(x);   // Output fractional tracking components via string pipeline
}
