//INTERRUPT
#include<lpc21xx.h>  /* Include standard LPC21xx microcontroller register definitions */
#include "interrupt.h" /* Include custom external interrupt definitions and pin constants */
#include "kpm.h"       /* Include Keypad Matrix scanning function prototypes (keyscan) */
#include "lcd.h"       /* Include LCD control and character printing prototypes */
#include "delay.h"     /* Include custom millisecond delay functions */

// Declare references to global runtime variables updated elsewhere in the application
extern int temp,hum,motor_time,flag;

/* 
 * Function: init_intr
 * Description: Configures the pin mapping for External Interrupt 1 (EINT1), sets it as edge-triggered,
 *              assigns it to standard IRQ slot 1, and enables the system interrupt pipeline.
 */
 void init_intr(void)
 {
 	//	PINSEL0&=((u32)~3<<6); // (Commented out line for clearing out bits 6 and 7 of Pin Select Register 0)
		PINSEL0|=EINT1_INPUT_PIN; // Map the target GPIO pin to serve its alternative function as EINT1
	VICIntSelect&=~(1<<15);    // Configure EINT1 (Interrupt Channel 15) as a standard IRQ (bit 15 = 0), not an FIQ
	VICIntEnable=1<<EINT1_VIC_CHNO; // Enable system-level routing for EINT1 in the VIC Interrupt Enable register

	VICVectCntl1=(1<<5)|EINT1_VIC_CHNO; // Vector Slot 1 configuration: Enable the slot (bit 5 = 1) and link it to EINT1 channel ID

	//load eint1_isr address into LUT sfr

  VICVectAddr1=(u32 ) eint1_isr; // Assign the memory address of our ISR handler directly to VIC Vector Address Slot 1
  EXTMODE=(1<<1);               // Configure EINT1 to trigger on an Edge (bit 1 = 1) instead of a Level condition
  }
									
/* 
 * Function: eint1_isr
 * Description: Interrupt Service Routine for EINT1. Automatically executes on the configured 
 *              signal edge, sets a polling flag, and clears the interrupt status.
 */
  void eint1_isr(void) __irq

{
	////	menu(); // (Commented out line to prevent nesting menu drawing directly within an execution critical ISR)
	flag=1; // Set a global flag variable to notify the main processing loop that a user interrupt happened
	//clear EINT1 Status in Ext Int Peripheral

	EXTINT=1<<1; // Write a 1 to bit 1 of External Interrupt flag register to clear the pending EINT1 latch

	//clear EINT1 status in VIC peripheral

	VICVectAddr=0; // Dummy write to the Vector Address register to signal the end of interrupt execution to the VIC hardware

}


   
unsigned char crop; // Allocation context container tracking current system crop mode state
extern unsigned char condition; // Declare reference to external state variable checking threshold limits

// Declare references to external environment threshold limit values
extern unsigned char temp_high;
extern unsigned char temp_medium_low;
extern unsigned char temp_medium_high;
extern unsigned char hum_high;
extern unsigned char hum_low;

// Declare references to external motor activation timer constants
extern unsigned int time1;
extern unsigned int time2;
extern unsigned int time3;

/* 
 * Function: menu
 * Description: Renders crop selection options on the LCD screen, captures a matrix keypad input, 
 *              and dynamically configures localized system temperature, humidity, and timer thresholds.
 */
void menu()
{
char key; // Local variable to store the pressed key value character
Write_CMD_LCD(0x01); // (Highly recommended addition to clear previous screen artifacts before rendering)
Write_CMD_LCD(0x80); // Move LCD cursor to Line 1, Column 1
  	Write_str_LCD("1.paddy 2.Vegetables"); // Print option 1 and option 2 markers on line 1
	Write_CMD_LCD(0xC0); // Move LCD cursor to Line 2, Column 1
	Write_str_LCD("3.Cotton 4.General");    // Print option 3 and option 4 markers on line 2
	key = keyscan(); // Execute blocking scanning function loop until a key is pressed on the matrix layout
switch(key) // Branch program execution path based on the character code returned from keypad matrix
{
    case '1':
        // Rice / Paddy Threshold Configurations
        temp_high = 32;          // Max survival temperature threshold set to 32 degrees Celsius
        temp_medium_low = 24;    // Optimal lower temperature boundary set to 24 degrees Celsius
        temp_medium_high = 31;   // Optimal upper temperature boundary set to 31 degrees Celsius
        hum_high = 70;           // High humidity alert cutoff limit marked at 70 percent
        hum_low = 55;            // Low humidity warning activation point marked at 55 percent

        time1 = 60000;     // Run Profile Duration Level 1 set to 60000ms (1 minute)
        time2 = 120000;    // Run Profile Duration Level 2 set to 120000ms (2 minutes)
        time3 = 180000;    // Run Profile Duration Level 3 set to 180000ms (3 minutes)
        break;


    case '2':
        // Chilli / Vegetables Threshold Configurations
        temp_high = 34;          // Max survival temperature threshold set to 34 degrees Celsius
        temp_medium_low = 25;    // Optimal lower temperature boundary set to 25 degrees Celsius
        temp_medium_high = 33;   // Optimal upper temperature boundary set to 33 degrees Celsius
        hum_high = 65;           // High humidity alert cutoff limit marked at 65 percent
        hum_low = 50;            // Low humidity warning activation point marked at 50 percent

        time1 = 60000;     // Run Profile Duration Level 1 set to 60000ms (1 minute)
        time2 = 120000;    // Run Profile Duration Level 2 set to 120000ms (2 minutes)
        time3 = 180000;    // Run Profile Duration Level 3 set to 180000ms (3 minutes)
        break;


    case '3':
        // Groundnut / Cotton Threshold Configurations
        temp_high = 35;          // Max survival temperature threshold set to 35 degrees Celsius
        temp_medium_low = 26;    // Optimal lower temperature boundary set to 26 degrees Celsius
        temp_medium_high = 34;   // Optimal upper temperature boundary set to 34 degrees Celsius
        hum_high = 60;           // High humidity alert cutoff limit marked at 60 percent
        hum_low = 45;            // Low humidity warning activation point marked at 45 percent

        time1 = 60000;     // Run Profile Duration Level 1 set to 60000ms (1 minute)
        time2 = 120000;    // Run Profile Duration Level 2 set to 120000ms (2 minutes)
        time3 = 180000;    // Run Profile Duration Level 3 set to 180000ms (3 minutes)
        break;


    case '4':
    default:
        // General AP Crop Mode Threshold Configurations (Fallback default state for invalid key codes)
        temp_high = 35;          // Max survival temperature threshold set to 35 degrees Celsius
        temp_medium_low = 25;    // Optimal lower temperature boundary set to 25 degrees Celsius
        temp_medium_high = 34;   // Optimal upper temperature boundary set to 34 degrees Celsius
        hum_high = 70;           // High humidity alert cutoff limit marked at 70 percent
        hum_low = 50;            // Low humidity warning activation point marked at 50 percent

        time1 = 60000;     // Run Profile Duration Level 1 set to 60000ms (1 minute)
        time2 = 120000;    // Run Profile Duration Level 2 set to 120000ms (2 minutes)
        time3 = 180000;    // Run Profile Duration Level 3 set to 180000ms (3 minutes)
        break;
}
}
