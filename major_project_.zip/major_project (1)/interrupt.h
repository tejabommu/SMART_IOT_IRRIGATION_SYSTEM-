#define EINT1_INPUT_PIN 0x000000C0

#define EINT1_VIC_CHNO  15


void init_intr(void);
void eint1_isr(void) __irq;
void menu(void);
 

