#include <string.h> // Include standard string handling functions (e.g., strstr, memset)
#include "uart0.h"   // Include UART0 initialization and transmission functions
#include "delay.h"   // Include custom millisecond delay functions
#include "lcd.h"     // Include LCD interface functions (e.g., Write_CMD_LCD, Write_str_LCD)

extern char buff[200];     // Declare reference to global RX buffer filled by UART ISR
extern unsigned char i;    // Declare reference to global index counter tracked by UART ISR

/* 
 * Function: esp01_connectAP
 * Description: Initializes the ESP-01 module, turns off echo, sets single connection mode, 
 *              disconnects from existing networks, and connects to a specific Wi-Fi Access Point.
 */
void esp01_connectAP()
{
	// --- STEP 1: Send basic AT attention command ---
	Write_CMD_LCD(0x01); // Clear LCD screen
	Write_CMD_LCD(0x80); // Set cursor to Line 1, Column 1
	Write_str_LCD("AT"); // Print status tag on LCD
	delay_ms(1000);      // Stability delay before sending
	UART0_Str("AT\r\n"); // Send attention command to ESP-01 via UART
	i=0;memset(buff,'\0',200); // Reset buffer index and clear the reception array
	while(i<4);          // Blocking wait until at least 4 characters are received via ISR
	delay_ms(500);       // Wait for response text stream to settle
	buff[i] = '\0';      // Append null terminator to safe-guard the string
	Write_CMD_LCD(0x01); // Clear LCD screen
	Write_CMD_LCD(0x80); // Move cursor to home position
	Write_str_LCD(buff); // Print received ESP-01 response text on LCD
	delay_ms(2000);      // Visual delay to read response
	if(strstr(buff,"OK")) // Check if response contains verification keyword "OK"
	{
		Write_CMD_LCD(0xC0); // Move cursor to Line 2, Column 1
		Write_str_LCD("OK"); // Indicate successful command response
		delay_ms(1000);		
	}
	else
	{
		Write_CMD_LCD(0xC0);    // Move cursor to Line 2, Column 1
		Write_str_LCD("ERROR"); // Indicate initialization failure
		delay_ms(1000);		
		return;                 // Abort initialization pipeline
	}
	
	// --- STEP 2: Turn off command echoing (ATE0) ---
	Write_CMD_LCD(0x01);   // Clear LCD screen
	Write_CMD_LCD(0x80);   // Move cursor to home position
	Write_str_LCD("ATE0"); // Print status tag on LCD
	delay_ms(1000);        // Stability delay before sending
	UART0_Str("ATE0\r\n"); // Send command to disable command echoing
	i=0;memset(buff,'\0',200); // Reset buffer index and clear reception array
	while(i<4);            // Wait for response characters
	delay_ms(500);         // Wait for data settlement
	buff[i] = '\0';        // Null terminate buffer
	Write_CMD_LCD(0x01);   // Clear LCD screen
	Write_CMD_LCD(0x80);   // Move cursor to home position
	Write_str_LCD(buff);   // Print response text on LCD
	delay_ms(2000);        // Visual delay to read response
	if(strstr(buff,"OK"))   // Verify if echo turning off was accepted
	{
		Write_CMD_LCD(0xC0); // Move cursor to Line 2
		Write_str_LCD("OK"); // Print success verification
		delay_ms(1000);		
	}
	else
	{
		Write_CMD_LCD(0xC0);    // Move cursor to Line 2
		Write_str_LCD("ERROR"); // Print failure status
		delay_ms(1000);		
		return;                 // Abort initialization pipeline
	}
	
	// --- STEP 3: Configure Single Connection Mode (CIPMUX=0) ---
	Write_CMD_LCD(0x01);       // Clear LCD screen
	Write_CMD_LCD(0x80);       // Move cursor to home position
	Write_str_LCD("AT+CIPMUX"); // Print status tag on LCD
	delay_ms(1000);            // Stability delay before sending
	UART0_Str("AT+CIPMUX=0\r\n"); // Set ESP-01 to Single MUX connection mode
	i=0;memset(buff,'\0',200); // Reset buffer index and clear reception array
	while(i<4);                // Wait for response characters
	delay_ms(500);             // Wait for data settlement
	buff[i] = '\0';            // Null terminate buffer
	Write_CMD_LCD(0x01);       // Clear LCD screen
	Write_CMD_LCD(0x80);       // Move cursor to home position
	Write_str_LCD(buff);       // Print response text on LCD
	delay_ms(2000);            // Visual delay to read response
	if(strstr(buff,"OK"))       // Verify mode acceptance
	{
		Write_CMD_LCD(0xC0); // Move cursor to Line 2
		Write_str_LCD("OK"); // Print success verification
		delay_ms(1000);		
	}
	else
	{
		Write_CMD_LCD(0xC0);    // Move cursor to Line 2
		Write_str_LCD("ERROR"); // Print failure status
		delay_ms(1000);		
		return;                 // Abort initialization pipeline
	}
	
	// --- STEP 4: Disconnect from any current Access Point (CWQAP) ---
	Write_CMD_LCD(0x01);      // Clear LCD screen
	Write_CMD_LCD(0x80);      // Move cursor to home position
	Write_str_LCD("AT+CWQAP"); // Print status tag on LCD
	delay_ms(1000);           // Stability delay before sending
	UART0_Str("AT+CWQAP\r\n"); // Command ESP-01 to quit/disconnect from AP
	i=0;memset(buff,'\0',200); // Reset buffer index and clear reception array
	while(i<4);               // Wait for response characters
	delay_ms(1500);           // Long settlement delay to handle network teardown
	buff[i] = '\0';           // Null terminate buffer
	Write_CMD_LCD(0x01);      // Clear LCD screen
	Write_CMD_LCD(0x80);      // Move cursor to home position
	Write_str_LCD(buff);      // Print response text on LCD
	delay_ms(2000);           // Visual delay to read response
	if(strstr(buff,"OK"))      // Verify successful disconnection
	{
		Write_CMD_LCD(0xC0); // Move cursor to Line 2
		Write_str_LCD("OK"); // Print success verification
		delay_ms(1000);		
	}
	else
	{
		Write_CMD_LCD(0xC0);    // Move cursor to Line 2
		Write_str_LCD("ERROR"); // Print failure status
		delay_ms(1000);		
		return;                 // Abort initialization pipeline
	}
	
	// --- STEP 5: Join designated Wi-Fi Access Point (CWJAP) ---
	Write_CMD_LCD(0x01);      // Clear LCD screen
	Write_CMD_LCD(0x80);      // Move cursor to home position
	Write_str_LCD("AT+CWJAP"); // Print status tag on LCD
	delay_ms(1000);           // Stability delay before sending
	// Sends connection parameter command with target SSID ("Teja") and Password ("teja0987")
	UART0_Str("AT+CWJAP=\"Teja\",\"teja0987\"\r\n");
	i=0;memset(buff,'\0',200); // Reset buffer index and clear reception array
	while(i<4);               // Wait for early characters
	delay_ms(2500);           // Extended delay allowing ESP-01 to complete network handshake
	buff[i] = '\0';           // Null terminate buffer
	Write_CMD_LCD(0x01);      // Clear LCD screen
	Write_CMD_LCD(0x80);      // Move cursor to home position
	Write_str_LCD(buff);      // Print connection result string on LCD
	delay_ms(2000);           // Visual delay to read response
	if(strstr(buff,"WIFI CONNECTED")) // Verify structural keyword match for successful link
	{
		Write_CMD_LCD(0xC0); // Move cursor to Line 2
		Write_str_LCD("OK"); // Print success verification
		delay_ms(1000);		
	}
	else
	{
		Write_CMD_LCD(0xC0);    // Move cursor to Line 2
		Write_str_LCD("ERROR"); // Print failure status
		delay_ms(1000);		
		return;                 // Exit function due to failed link
	}
	
}

/* 
 * Function: esp01_sendToThingspeak
 * Description: Establishes TCP connection to ThingSpeak server, sends 48 bytes 
 *              of custom HTTP GET request packet data targeting Field 3.
 */
void esp01_sendToThingspeak(int val)
{
	// --- STEP 1: Start TCP Connection ---
	Write_CMD_LCD(0x01);          // Clear LCD screen
	Write_CMD_LCD(0x80);          // Move cursor to home position
	Write_str_LCD("AT+CIPSTART"); // Print status tag on LCD
	delay_ms(1000);               // Stability delay before sending
	UART0_Str("AT+CIPSTART=\"TCP\",\"api.thingspeak.com\",80\r\n"); // Connect to ThingSpeak port 80 over TCP
	i=0;memset(buff,'\0',200);     // Reset buffer index and clear reception array
	while(i<5);                   // Wait for response characters
	delay_ms(2500);               // Delay to complete the TCP handshake connection routing
	buff[i] = '\0';               // Null terminate buffer
	Write_CMD_LCD(0x01);          // Clear LCD screen
	Write_CMD_LCD(0x80);          // Move cursor to home position
	Write_str_LCD(buff);          // Print handshake response on LCD
	delay_ms(2000);               // Visual delay to read response
	if(strstr(buff,"CONNECT") || strstr(buff,"ALREADY CONNECTED")) // Confirm network socket is open
	{
		Write_CMD_LCD(0xC0); // Move cursor to Line 2
		Write_str_LCD("OK"); // Print success verification
		delay_ms(1000);
		
		// --- STEP 2: Configure Send Buffer Length ---
		Write_CMD_LCD(0x01);         // Clear LCD screen
		Write_CMD_LCD(0x80);         // Move cursor to home position
		Write_str_LCD("AT+CIPSEND"); // Print status tag on LCD
		delay_ms(1000);              // Stability delay before sending
		UART0_Str("AT+CIPSEND=48\r\n"); // Alert ESP-01 that an incoming 48-byte payload is expected
		i=0;memset(buff,'\0',200);   // Reset buffer index and clear reception array
		//while(buff[i] != '>');    // Commented out hardware tracking approach
		delay_ms(500);               // Fixed wait layout for ESP-01 to prepare prompt window
		
		// --- STEP 3: Transmit HTTP GET Request Data Payload ---
		UART0_Str("GET /update?api_key=OOJE4DGTACY3WNDH&field3="); // Send ThingSpeak write API segment with targeting
		UART0_Int(val);              // Write out the current runtime variable value into string
		UART0_Str("\r\n\r\n");       // Send required standard trailing HTTP spacing sequence
		delay_ms(5000);              // Extended transmission delay block for processing
		delay_ms(5000);              // Secondary extended wait segment for completion confirmation
		buff[i] = '\0';              // Null terminate data collection buffer
		Write_CMD_LCD(0x01);         // Clear LCD screen
		Write_CMD_LCD(0x80);         // Move cursor to home position
		Write_str_LCD(buff);         // Display transmission response packet trace
		delay_ms(2000);              // Visual delay to read response
		if(strstr(buff,"SEND OK"))    // Look for success transaction token
		{
			Write_CMD_LCD(0x01);         // Clear LCD screen
			Write_str_LCD("DATA UPDATED"); // Display confirmation statement
			delay_ms(1000);			
		}
		/*
		else if(!strstr(buff,"CLOSED")) // (Commented Out Structure block for handling socket closings)
		{
			Write_CMD_LCD(0x01);
			Write_CMD_LCD(0x80);
			Write_str_LCD("AT+CIPCLOSE");
			delay_ms(1000);
			UART0_Str("AT+CIPCLOSE\r\n");
			i=0;memset(buff,'\0',200);
			while(i<5);
			delay_ms(2500);
			buff[i] = '\0';
			Write_CMD_LCD(0x01);
			Write_CMD_LCD(0x80);
			Write_str_LCD(buff);
			delay_ms(2000);
			if(strstr(buff,"OK"))
			{
				Write_CMD_LCD(0x01);
				Write_CMD_LCD(0x80);
				Write_str_LCD("OK");
				delay_ms(2000);				
			}
			else
			{
				Write_CMD_LCD(0x01);
				Write_CMD_LCD(0x80);
				Write_str_LCD("ERROR");
				delay_ms(2000);		
			}
		
		}*/
		else
		{
			Write_CMD_LCD(0x01);             // Clear LCD screen
			Write_str_LCD("DATA NOT UPDATED"); // Indicate upload update transaction failure
			delay_ms(1000);	
		}
		
	}
	else
	{
		Write_CMD_LCD(0xC0);    // Move cursor to Line 2
		Write_str_LCD("ERROR"); // Indicate TCP tracking or setup connection error
		delay_ms(1000);		
		return;                 // Abort sending pipeline
	}

	
}

/* 
 * Function: esp01_sendToThingspeak2
 * Description: Establishes TCP connection to ThingSpeak server, sends 48 bytes 
 *              of custom HTTP GET request packet data targeting Field 2.
 */
void esp01_sendToThingspeak2(int val)
{
	// --- STEP 1: Start TCP Connection ---
	Write_CMD_LCD(0x01);          // Clear LCD screen
	Write_CMD_LCD(0x80);          // Move cursor to home position
	Write_str_LCD("AT+CIPSTART"); // Print status tag on LCD
	delay_ms(1000);               // Stability delay before sending
	UART0_Str("AT+CIPSTART=\"TCP\",\"api.thingspeak.com\",80\r\n"); // Connect to ThingSpeak port 80 over TCP
	i=0;memset(buff,'\0',200);     // Reset buffer index and clear reception array
	while(i<5);                   // Wait for response characters
	delay_ms(2500);               // Delay to complete the TCP handshake connection routing
	buff[i] = '\0';               // Null terminate buffer
	Write_CMD_LCD(0x01);          // Clear LCD screen
	Write_CMD_LCD(0x80);          // Move cursor to home position
	Write_str_LCD(buff);          // Print handshake response on LCD
	delay_ms(2000);               // Visual delay to read response
	if(strstr(buff,"CONNECT") || strstr(buff,"ALREADY CONNECTED")) // Confirm network socket is open
	{
		Write_CMD_LCD(0xC0); // Move cursor to Line 2
		Write_str_LCD("OK"); // Print success verification
		delay_ms(1000);
		
		// --- STEP 2: Configure Send Buffer Length ---
		Write_CMD_LCD(0x01);         // Clear LCD screen
		Write_CMD_LCD(0x80);         // Move cursor to home position
		Write_str_LCD("AT+CIPSEND"); // Print status tag on LCD
		delay_ms(1000);              // Stability delay before sending
		UART0_Str("AT+CIPSEND=48\r\n"); // Alert ESP-01 that an incoming 48-byte payload is expected
		i=0;memset(buff,'\0',200);   // Reset buffer index and clear reception array
		//while(buff[i] != '>');    // Commented out hardware tracking approach
		delay_ms(500);               // Fixed wait layout for ESP-01 to prepare prompt window
		
		// --- STEP 3: Transmit HTTP GET Request Data Payload ---
		UART0_Str("GET /update?api_key=OOJE4DGTACY3WNDH&field2="); // Send ThingSpeak write API segment with targeting
		UART0_Int(val);              // Write out the current runtime variable value into string
		UART0_Str("\r\n\r\n");       // Send required standard trailing HTTP spacing sequence
		delay_ms(5000);              // Extended transmission delay block for processing
		delay_ms(5000);              // Secondary extended wait segment for completion confirmation
		buff[i] = '\0';              // Null terminate data collection buffer
		Write_CMD_LCD(0x01);         // Clear LCD screen
		Write_CMD_LCD(0x80);         // Move cursor to home position
		Write_str_LCD(buff);         // Display transmission response packet trace
		delay_ms(2000);              // Visual delay to read response
		if(strstr(buff,"SEND OK"))    // Look for success transaction token
		{
			Write_CMD_LCD(0x01);         // Clear LCD screen
			Write_str_LCD("DATA UPDATED"); // Display confirmation statement
			delay_ms(1000);			
		}
		/*
		else if(!strstr(buff,"CLOSED")) // (Commented Out Structure block for handling socket closings)
		{
			Write_CMD_LCD(0x01);
			Write_CMD_LCD(0x80);
			Write_str_LCD("AT+CIPCLOSE");
			delay_ms(1000);
			UART0_Str("AT+CIPCLOSE\r\n");
			i=0;memset(buff,'\0',200);
			while(i<5);
			delay_ms(2500);
			buff[i] = '\0';
			Write_CMD_LCD(0x01);
			Write_CMD_LCD(0x80);
			Write_str_LCD(buff);
			delay_ms(2000);
			if(strstr(buff,"OK"))
			{
				Write_CMD_LCD(0x01);
				Write_CMD_LCD(0x80);
				Write_str_LCD("OK");
				delay_ms(2000);				
			}
			else
			{
				Write_CMD_LCD(0x01);
				Write_CMD_LCD(0x80);
				Write_str_LCD("ERROR");
				delay_ms(2000);		
			}
		
		}*/
		else
		{
			Write_CMD_LCD(0x01);             // Clear LCD screen
			Write_str_LCD("DATA NOT UPDATED"); // Indicate upload update transaction failure
			delay_ms(1000);	
		}
		
	}
	else
	{
		Write_CMD_LCD(0xC0);    // Move cursor to Line 2
		Write_str_LCD("ERROR"); // Indicate TCP tracking or setup connection error
		delay_ms(1000);		
		return;                 // Abort sending pipeline
	}

	
}

/* 
 * Function: esp01_sendToThingspeak3
 * Description: Establishes TCP connection to ThingSpeak server, sends 59 bytes 
 *              of custom HTTP GET data payloads targeting Field 1 AND Field 2 simultaneously.
 */
void esp01_sendToThingspeak3(int val,int val2)
{
	// --- STEP 1: Start TCP Connection ---
	Write_CMD_LCD(0x01);          // Clear LCD screen
	Write_CMD_LCD(0x80);          // Move cursor to home position
	Write_str_LCD("AT+CIPSTART"); // Print status tag on LCD
	delay_ms(1000);               // Stability delay before sending
	UART0_Str("AT+CIPSTART=\"TCP\",\"api.thingspeak.com\",80\r\n"); // Connect to ThingSpeak port 80 over TCP
	i=0;memset(buff,'\0',200);     // Reset buffer index and clear reception array
	while(i<5);                   // Wait for response characters
	delay_ms(2500);               // Delay to complete the TCP handshake connection routing
	buff[i] = '\0';               // Null terminate buffer
	Write_CMD_LCD(0x01);          // Clear LCD screen
	Write_CMD_LCD(0x80);          // Move cursor to home position
	Write_str_LCD(buff);          // Print handshake response on LCD
	delay_ms(2000);               // Visual delay to read response
	if(strstr(buff,"CONNECT") || strstr(buff,"ALREADY CONNECTED")) // Confirm network socket is open
	{
		Write_CMD_LCD(0xC0); // Move cursor to Line 2
		Write_str_LCD("OK"); // Print success verification
		delay_ms(1000);
		
		// --- STEP 2: Configure Send Buffer Length ---
		Write_CMD_LCD(0x01);         // Clear LCD screen
		Write_CMD_LCD(0x80);         // Move cursor to home position
		Write_str_LCD("AT+CIPSEND"); // Print status tag on LCD
		delay_ms(1000);              // Stability delay before sending
		UART0_Str("AT+CIPSEND=59\r\n"); // Alert ESP-01 that an incoming 59-byte payload is expected
		i=0;memset(buff,'\0',200);   // Reset buffer index and clear reception array
		//while(buff[i] != '>');    // Commented out hardware tracking approach
		delay_ms(500);               // Fixed wait layout for ESP-01 to prepare prompt window
		
		// --- STEP 3: Transmit Dual-Field HTTP GET Request Data Payload ---
		UART0_Str("GET /update?api_key=OOJE4DGTACY3WNDH&field1="); // Send key parameter matching segment
		UART0_Int(val);              // Write out first dynamic runtime variable into string segment (Field 1)
		UART0_Str("&field2=");        // Append secondary targeting link marker
		UART0_Int(val2);             // Write out second dynamic runtime variable into string segment (Field 2)
		UART0_Str("\r\n\r\n");       // Send required standard trailing HTTP spacing sequence
		delay_ms(5000);              // Extended transmission delay block for processing
		delay_ms(5000);              // Secondary extended wait segment for completion confirmation
		buff[i] = '\0';              // Null terminate data collection buffer
		Write_CMD_LCD(0x01);         // Clear LCD screen
		Write_CMD_LCD(0x80);         // Move cursor to home position
		Write_str_LCD(buff);         // Display transmission response packet trace
		delay_ms(2000);              // Visual delay to read response
		if(strstr(buff,"SEND OK"))    // Look for success transaction token
		{
			Write_CMD_LCD(0x01);         // Clear LCD screen
			Write_str_LCD("DATA UPDATED"); // Display confirmation statement
			delay_ms(1000);			
		}
		/*
		else if(!strstr(buff,"CLOSED")) // (Commented Out Structure block for handling socket closings)
		{
			Write_CMD_LCD(0x01);
			Write_CMD_LCD(0x80);
			Write_str_LCD("AT+CIPCLOSE");
			delay_ms(1000);
			UART0_Str("AT+CIPCLOSE\r\n");
			i=0;memset(buff,'\0',200);
			while(i<5);
			delay_ms(2500);
			buff[i] = '\0';
			Write_CMD_LCD(0x01);
			Write_CMD_LCD(0x80);
			Write_str_LCD(buff);
			delay_ms(2000);
			if(strstr(buff,"OK"))
			{
				Write_CMD_LCD(0x01);
				Write_CMD_LCD(0x80);
				Write_str_LCD("OK");
				delay_ms(2000);				
			}
			else
			{
				Write_CMD_LCD(0x01);
				Write_CMD_LCD(0x80);
				Write_str_LCD("ERROR");
				delay_ms(2000);		
			}
		
		}*/
		else
		{
			Write_CMD_LCD(0x01);             // Clear LCD screen
			Write_str_LCD("DATA NOT UPDATED"); // Indicate upload update transaction failure
			delay_ms(1000);	
		}
		
	}
	else
	{
		Write_CMD_LCD(0xC0);    // Move cursor to Line 2
		Write_str_LCD("ERROR"); // Indicate TCP tracking or setup connection error
		delay_ms(1000);		
		return;                 // Abort sending pipeline
	}

	
}
