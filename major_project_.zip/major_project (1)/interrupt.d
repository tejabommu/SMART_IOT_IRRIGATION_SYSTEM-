interrupt.o: interrupt.c
interrupt.o: C:\KeilARM\ARM\INC\Philips\lpc21xx.h
interrupt.o: interrupt.h
interrupt.o: kpm.h
interrupt.o: types.h
interrupt.o: lcd.h
interrupt.o: delay.h
