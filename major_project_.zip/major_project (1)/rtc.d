rtc.o: rtc.c
rtc.o: C:\KeilARM\ARM\INC\Philips\lpc21xx.h
