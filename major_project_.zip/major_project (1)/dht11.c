#include <lpc214x.h>   /* Include specific LPC2148 hardware register definitions */

#include "delay.h"     /* Include custom millisecond and microsecond delay functions */
#include "defines.h"   /* Include custom macro definitions (like WRITEBIT, READBIT) */

#define input 0        // Direction macro to configure GPIO pin as Input
#define output 1       // Direction macro to configure GPIO pin as Output

#define DHT11 4	       // DHT11 data pin mapped to GPIO Port 0 Pin 4 (P0.4)


/* 
 * Function: dht11_request
 * Description: Generates the master start signal sequence required to wake up 
 *              the DHT11 sensor and request a data transmission.
 */
void dht11_request(void)
{
	WRITEBIT(IODIR0,DHT11,output);	// Configure the DHT11 pin as an output pin in the Port 0 Direction register
	WRITEBIT(IOPIN0,DHT11,0);       // Pull the DHT11 pin LOW to alert the sensor (comment text says 18 seconds, but logic uses 20ms)
	delay_ms(20);                   // Keep line LOW for 20ms (DHT11 requires a minimum of 18ms to detect the start signal)
	WRITEBIT(IOPIN0,DHT11,1);       // Pull the pin back HIGH to let the bus float and wait for the sensor's response
}

/* 
 * Function: dht11_response
 * Description: Hands over control to the sensor, then blocks and synchronizes 
 *              with the standard 80�s LOW followed by 80�s HIGH acknowledgement pulse.
 */
void dht11_response(void)
{
	WRITEBIT(IODIR0,DHT11,input);	   // Reconfigure the DHT11 pin as an input pin to receive data from the sensor
	while(READBIT(IOPIN0,DHT11) == 1); // Blocking wait while the data line stays HIGH (waiting for sensor to pull it down)
	while(READBIT(IOPIN0,DHT11) == 0); // Blocking wait while the sensor pulls the line LOW for its ~80�s startup pulse
	while(READBIT(IOPIN0,DHT11) == 1); // Blocking wait while the sensor pulls the line HIGH for its ~80�s initialization pulse
}

/* 
 * Function: dht11_data
 * Description: Reads a single 8-bit byte from the sensor bit-by-bit by measuring 
 *              the duration of the received pulse width.
 */
unsigned char dht11_data(void)
{
	unsigned char count;               // Loop counter variable for tracking the 8 bits
	unsigned char data = 0;            // Temporary storage byte to assemble the received bits
	for(count = 0; count<8 ; count++)	// Loop 8 times to construct a complete data byte
	{
		while(READBIT(IOPIN0,DHT11) == 0);	// Blocking wait for the ~50�s preamble pulse that precedes every single bit
		delay_us(30);	                    // Wait for 30�s (Critical window: Bit '0' finishes by 28�s, Bit '1' lasts for 70�s)
		if (READBIT(IOPIN0,DHT11))          // Sample the line state: If it is still HIGH after 30�s, a logic '1' is received
			data = ( (data<<1) | 0x01 );    // Shift the data byte left by 1 bit and set the lowest bit to 1
		else	                            // If the line has already fallen back to LOW, a logic '0' is received
			data = (data<<1);               // Shift the data byte left by 1 bit (leaves the lowest bit as 0)
		while(READBIT(IOPIN0,DHT11));	    // Blocking wait for the line to return to LOW (only loops if a logic '1' was received)
	}
	return data;                            // Return the fully assembled 8-bit data byte back to the caller
}
